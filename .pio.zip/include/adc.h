#include <stdint.h>

//method to initialsie adc init
void adc_adc_init();