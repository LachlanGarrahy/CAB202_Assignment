#include <stdio.h>

uint8_t* decode_decrypt(uint8_t* ENCODED, uint8_t* RESULT);

uint8_t* decode(uint8_t* ENCODED, uint8_t* DECRYPTED);

uint8_t* decrypt(uint8_t* DECRYPTED, uint8_t* RESULT);