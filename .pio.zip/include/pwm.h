#include <stdint.h>

//method to initilaise pwm
void pwm_pwm_init();
//method to adjust the brightness
void brightness_adjust(uint8_t input);