#include <stdint.h>
// method to display the hex digits
void display_hex_finder(uint8_t digit);