#include <stdint.h>
//method to initiliase spi
void spi_init();
//method to write to the spi
void spi_write(uint8_t b);