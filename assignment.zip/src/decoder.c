// #include <stdio.h>

// uint8_t[3]; decode(uint8_t ENCODED[4]){
    
//     uint8_t DECODED[3];

//     uint8_t high_byte;
//     uint8_t low_byte;
//     uint8_t byte;

//     high_byte = DecodeToBinary(TEST_BASE64[0]);
//     low_byte = DecodeToBinary(TEST_BASE64[1]);
//     byte = (high_byte << 2)|(low_byte >> 4);
//     DECODED[0] = byte;

//     high_byte = DecodeToBinary(TEST_BASE64[1]);
//     low_byte = DecodeToBinary(TEST_BASE64[2]);
//     byte = (high_byte << 4)|(low_byte >> 2);
//     DECODED[1] = byte;

//     high_byte = DecodeToBinary(TEST_BASE64[2]);
//     low_byte = DecodeToBinary(TEST_BASE64[3]);
//     byte = (high_byte << 6)|(low_byte);
//     DECODED[2] = byte;
// }

// uint8_t DecodeToBinary(uint8_t byte){
//     uint8_t number;
//     if (byte >= 'a' && byte <= 'z'){
//         number = byte - 'a' + 26;
//     }else if (byte >= 'A' && byte <= 'Z'){
//         number = byte - 'A' + 0;
//     }else if (byte >= '0' && byte <= '9'){
//         number =  byte - '0' + 52;
//     }
//     return number;
// }