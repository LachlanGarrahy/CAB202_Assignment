#include <stdint.h>

void display_hex_finder(uint8_t digit);