#include <stdint.h>

void timer_init();
void set_digits(uint8_t left, uint8_t right);