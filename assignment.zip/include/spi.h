#include <stdint.h>

void spi_init();
void spi_write(uint8_t b);
void spi_on();
void spi_off();