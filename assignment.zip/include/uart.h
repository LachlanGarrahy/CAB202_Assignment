#include <stdint.h>

void uart_init();
uint8_t uart_getc();
void uart_putc(uint8_t c);