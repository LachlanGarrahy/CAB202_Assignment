#include <stdint.h>

void adc_adc_init();