#include <stdint.h>

void buzz_init();
void sound_duty_cycle_adjust(uint16_t input);