#include <stdint.h>

void pwm_pwm_init();
void brightness_adjust(uint16_t input);